#ifndef TETRIS_H
#define TITRIS_H

#include <time.h>
#include "define.h"
#include "fsm.h"
#include "objects.h"
#include "backend.h"

void initGame();

#endif