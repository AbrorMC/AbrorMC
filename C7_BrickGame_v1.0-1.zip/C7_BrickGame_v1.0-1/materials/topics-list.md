# Topoics list

Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:

- finite state machines;
- working with matrices;
- working with files;
- working with the GUI library.

Now that you know what awaits you in this project, you can slowly begin to study the topics listed above. 😇
