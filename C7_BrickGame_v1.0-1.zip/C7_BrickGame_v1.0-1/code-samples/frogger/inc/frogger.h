#ifndef FROGGER_H
#define FROGGER_H

#include <locale.h>
#include "fsm.h"
#include "frog_backend.h"
#include "frog_frontend.h"

void game_loop();

#endif