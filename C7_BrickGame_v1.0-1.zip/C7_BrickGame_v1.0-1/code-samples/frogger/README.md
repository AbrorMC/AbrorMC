# Frogger
## Controls
### Movement
Arrow keys (up, right, down, left)
### Exit
Esc key
## Installation
```git clone XXX && cd frogger```
## Make
```make frogger``` makes switch-case realisation of fsm which you can observe in file src/fsm.c \
```make frogger_fsmtable``` makes fsm realisation based on matrix of pointers on state-control functions which you can observe in file src/fsm_matrix.c